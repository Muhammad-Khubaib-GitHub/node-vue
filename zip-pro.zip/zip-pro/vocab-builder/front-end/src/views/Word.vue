<template>
  <div>
    <h1>Words</h1>
    <table id="words" class="ui celled compact table">
      <thead>
        <tr>
          <th><i class="united kingdom flag"></i>English</th>
          <th> <i class="germany flag"></i> German</th>
          <th colspan="3"></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(word, i) in words" :key="i">
          <td>{{ word.english }}</td>
          <td>{{ word.german }}</td>
          <td width="75" class="center aligned">
            <router-link :to="{ name: 'show', params: { id: word._id } }">Show</router-link>
          </td>
          <td width="75" class="center aligned">
            <router-link :to="{ name: 'edit', params: { id: word.id } }">Edit</router-link>
          </td>
          <td width="75" class="center aligned">
            <a href="#" @click.prevent="onDestroy(word._id)">Destroy</a>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { api } from '../helpers/helpers';

export default {
  name: 'words',
  data() {
    return {
      words: []
    };
  },
  async mounted() {
    this.words = await api.getWords();
  },
  methods: {
    showWord(word) {
      alert(`English: ${word.english}, German: ${word.german}`);
    },

    async onDestroy(id) {
    const sure = window.confirm('Are you sure you want to delete this word?');
    if (!sure) return;
    
    try {
      await api.deleteWord(id);
      this.flash('Word deleted successfully!', 'success');
      this.words = this.words.filter(word => word._id !== id);
    } catch (error) {
      this.flash('Failed to delete word', 'error');
      console.error('Delete error:', error);
    }
  },

    editWord(word) {
    this.$router.push({
      name: 'edit',
      params: { id: word } 
    });
  },
    async deleteWord(id) {
        
        this.words = await api.getWords();
    }
  }
};
</script>

<style scoped>
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: center;
}
th {
  background-color: #f4f4f4;
}
button {
  padding: 5px 10px;
  border: none;
  background-color: #2185d0;
  color: white;
  cursor: pointer;
  border-radius: 3px;
}
button:hover {
  background-color: #1678c2;
}
</style>
