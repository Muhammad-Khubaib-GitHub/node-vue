<template>
  <div>
    <h1>Edit Word</h1>
    <word-form @createOrUpdate="createOrUpdate" :word="word"></word-form>
  </div>
</template>

<script>
import WordForm from '../components/WordForm.vue';
import { api } from '../helpers/helpers';

export default {
  name: 'edit',
  components: {
    'word-form': WordForm
  },
  data: function() {
    return {
      word: {}
    };
  },
  async mounted() {
    try {
    const response = await api.getWord(this.$route.params.id);
    if (!response || !response.length) {
      throw new Error('Word not found');
    }
    this.word = response[0];
  } catch (error) {
    console.error('Error loading word:', error);
    this.$router.push('/'); // Redirect if error
  }
  },

  methods: {
  async createOrUpdate(word) {
    try {
      await api.updateWord(word);
      this.flash('Word updated successfully!', 'success');
      this.$router.push(`/words/${word}`);
    } catch (error) {
      console.error('Failed to update word:', error);
      alert('Failed to update word. Please try again.');
    }
  }
}

};

</script>
